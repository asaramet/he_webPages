function asa = getAdditionalSubmitArguments(props)

% Copyright 2010-2014 The MathWorks, Inc.

asa = '';
currFilename = mfilename;

[~,flag] = strtok(props.MatlabArguments,'p');
if strcmp(flag,'parallel')
    w = props.NumberOfTasks;
else
    w = 1;
end

ppn = ClusterInfo.getProcsPerNode();
if isempty(ppn)==true
    % Default ppn count.
    % Specify ProcsPerNode below.
    ppn = 8;
end

% Don't request more cores/node than workers
ppn = min(w,ppn);
% Determine number of nodes
numberOfNodes = ceil(w/ppn);
asa = sprintf('%s -l nodes=%d:ppn=%d', asa, numberOfNodes, ppn);
dctSchedulerMessage(4, '%s: Requesting %d nodes with %d processors per node', currFilename, ...
numberOfNodes, ppn);


%% REQUIRED



%% OPTIONAL

% Check if user wants email updates
ea = ClusterInfo.getEmailAddress();
if isempty(ea)==false
    % User wants to be emailed the job status
    asa = [asa ' -M ' ea ' -m abe'];
end

% Query for the queue name
qn = ClusterInfo.getQueueName();
if isempty(qn)==false
    asa = [asa ' -q ' qn];
end

% Walltime
wt = ClusterInfo.getWallTime();
if isempty(wt) == false
    asa = [asa ' -l walltime=' wt];
end

% NOTE: NEEDS TO HAVE MOAB BUILT WITH TOOLS
%
% Every job is going to require a certain number of MDCS licenses.
% The Native RM job submission language provides a direct method of
% license specification.
%
% Moab:
%  1. Copy
%          $MOABHOMEDIR/tools/flexlm/license.mon.flexLM.pl
%     to
%          $MOABHOMEDIR/tools/flexlm/license.mon.matlab.flexLM.pl
%
%  2. Modify license.mon.matlab.flexLM.pl
%
%      my @FLEXlmCmds = ("$MATLAB/etc/glnxa64/lmutil lmstat -a -c $MATLAB/licenses/network.lic");
%
%  3. On headnode, modify $MOABHOMEDIR/.../moab.cfg
%
%      RMCFG[FLEXlm1]     TYPE=NATIVE RESOURCETYPE=LICENSE
%      RMCFG[FLEXlm1]     CLUSTERQUERYURL=exec://$TOOLSDIR/flexlm/license.mon.matlab.flexLM.pl
%
asa = sprintf('%s -l software=MATLAB_Distrib_Comp_Engine:%d',asa,w);

% Catch-all
udo = ClusterInfo.getUserDefinedOptions();
if isempty(udo)==false
    asa = [asa ' ' udo];
end

asa = strtrim(asa);
